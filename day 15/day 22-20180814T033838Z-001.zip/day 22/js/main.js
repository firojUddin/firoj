
var firstNumber = document.getElementById("firstValue");
var lastNumber = document.getElementById('lastValue');
var result = document.getElementById('result');

var add = document.getElementById("addition");
add.onclick = function () {
    result.value = Number(firstNumber.value)+Number(lastNumber.value);
};
var sub = document.getElementById('subtraction');
sub.onclick = function () {
    result.value = Number(firstNumber.value)-Number(lastNumber.value);
};
var mul = document.getElementById('multiple');
mul.onclick = function () {
    result.value = Number(firstNumber.value)*Number(lastNumber.value);
};
var div = document.getElementById('division');
div.onclick = function () {
    result.value = Number(firstNumber.value)/Number(lastNumber.value);
};
var mod = document.getElementById('modular');
mod.onclick = function () {
    result.value = Number(firstNumber.value)%Number(lastNumber.value);
};
